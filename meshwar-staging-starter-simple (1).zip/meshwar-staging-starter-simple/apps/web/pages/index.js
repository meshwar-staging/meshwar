export default function Home() {
  return <div>Meshwar staging app is running.</div>;
}
