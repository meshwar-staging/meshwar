// Shared types placeholder
