# Meshwar Staging Starter (Simplified)

This repository is a simplified starter for the Meshwar staging project. It includes:

- `apps/api`: A basic Node.js Express backend with a single health endpoint.
- `apps/web`: A basic Next.js frontend with a single page.
- `packages/types`: Shared TypeScript types (empty placeholder).

This minimal starter is intended for quick testing or reference.
